"""下载 Imagenette 数据集 (ImageNet 10类子集, 约1.5GB)"""
import os
import urllib.request
import tarfile
import sys

# 320px 版本 (~1.5GB 解压后)
URL = "https://s3.amazonaws.com/fast-ai-imageclas/imagenette2-320.tgz"
FILENAME = "imagenette2-320.tgz"
EXTRACT_DIR = r"d:\Personal\Desktop\AI\实验\No.4"


def download_with_progress(url, filename):
    """带进度条的下载"""
    def report_progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        percent = min(100, downloaded * 100 / total_size)
        mb_downloaded = downloaded / (1024 * 1024)
        mb_total = total_size / (1024 * 1024)
        sys.stdout.write(f"\r下载进度: {percent:.1f}% ({mb_downloaded:.1f}/{mb_total:.1f} MB)")
        sys.stdout.flush()
    
    print(f"正在下载: {url}")
    urllib.request.urlretrieve(url, filename, report_progress)
    print("\n下载完成!")


def extract_tarfile(filename, extract_dir):
    """解压 tar.gz 文件"""
    print(f"正在解压: {filename}")
    with tarfile.open(filename, "r:gz") as tar:
        tar.extractall(path=extract_dir)
    print("解压完成!")


def main():
    os.makedirs(EXTRACT_DIR, exist_ok=True)
    filepath = os.path.join(EXTRACT_DIR, FILENAME)
    
    # 检查是否已存在
    extract_path = os.path.join(EXTRACT_DIR, "imagenette2-320")
    if os.path.exists(extract_path):
        print(f"数据集已存在: {extract_path}")
        return
    
    # 下载
    if not os.path.exists(filepath):
        download_with_progress(URL, filepath)
    else:
        print(f"压缩包已存在: {filepath}")
    
    # 解压
    extract_tarfile(filepath, EXTRACT_DIR)
    
    # 删除压缩包
    os.remove(filepath)
    print(f"\n数据集已准备好: {extract_path}")
    print("类别: tench, English springer, cassette player, chain saw,")
    print("      church, French horn, garbage truck, gas pump, golf ball, parachute")


if __name__ == "__main__":
    main()
