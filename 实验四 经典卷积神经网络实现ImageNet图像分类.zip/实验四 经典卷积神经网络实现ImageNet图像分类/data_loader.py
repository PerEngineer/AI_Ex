"""
图像分类数据加载模块
支持: Tiny ImageNet, Imagenette
"""
import os
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image


class TinyImageNetDataset(Dataset):
    """Tiny ImageNet 数据集类"""
    
    def __init__(self, root_dir, split='train', transform=None, 
                 num_classes=None, samples_per_class=None):
        """
        Args:
            root_dir: Tiny ImageNet 数据集根目录
            split: 'train' 或 'val'
            transform: 图像变换
            num_classes: 使用的类别数量 (None表示全部200类)
            samples_per_class: 每个类别的样本数量 (None表示全部)
        """
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.samples_per_class = samples_per_class
        self.images = []
        self.labels = []
        
        # 读取类别ID列表
        wnids_file = os.path.join(root_dir, 'wnids.txt')
        with open(wnids_file, 'r') as f:
            self.class_ids = [line.strip() for line in f.readlines()]
        
        # 限制类别数量
        if num_classes is not None:
            self.class_ids = self.class_ids[:num_classes]
        
        # 创建类别ID到索引的映射
        self.class_to_idx = {cls_id: idx for idx, cls_id in enumerate(self.class_ids)}
        
        if split == 'train':
            self._load_train_data()
        elif split == 'val':
            self._load_val_data()
        else:
            raise ValueError(f"split must be 'train' or 'val', got {split}")
    
    def _load_train_data(self):
        """加载训练数据"""
        train_dir = os.path.join(self.root_dir, 'train')
        for class_id in self.class_ids:
            class_dir = os.path.join(train_dir, class_id, 'images')
            if os.path.exists(class_dir):
                count = 0
                for img_name in os.listdir(class_dir):
                    if img_name.endswith('.JPEG'):
                        # 限制每个类别的样本数量
                        if self.samples_per_class is not None and count >= self.samples_per_class:
                            break
                        self.images.append(os.path.join(class_dir, img_name))
                        self.labels.append(self.class_to_idx[class_id])
                        count += 1
    
    def _load_val_data(self):
        """加载验证数据"""
        val_dir = os.path.join(self.root_dir, 'val')
        val_annotations_file = os.path.join(val_dir, 'val_annotations.txt')
        
        # 读取验证集标注
        img_to_class = {}
        with open(val_annotations_file, 'r') as f:
            for line in f.readlines():
                parts = line.strip().split('\t')
                img_name = parts[0]
                class_id = parts[1]
                img_to_class[img_name] = class_id
        
        # 加载验证集图片
        val_images_dir = os.path.join(val_dir, 'images')
        for img_name in os.listdir(val_images_dir):
            if img_name.endswith('.JPEG'):
                self.images.append(os.path.join(val_images_dir, img_name))
                class_id = img_to_class[img_name]
                self.labels.append(self.class_to_idx[class_id])
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        # 加载图像
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return image, label


class ImagenetteDataset(Dataset):
    """Imagenette 数据集类 (ImageNet 10类子集，约1.5GB)"""
    
    # 10个类别的文件夹名和对应标签
    CLASSES = [
        'n01440764',  # tench
        'n02102040',  # English springer
        'n02979186',  # cassette player
        'n03000684',  # chain saw
        'n03028079',  # church
        'n03394916',  # French horn
        'n03417042',  # garbage truck
        'n03425413',  # gas pump
        'n03445777',  # golf ball
        'n03888257',  # parachute
    ]
    
    CLASS_NAMES = [
        'tench', 'English springer', 'cassette player', 'chain saw',
        'church', 'French horn', 'garbage truck', 'gas pump',
        'golf ball', 'parachute'
    ]
    
    def __init__(self, root_dir, split='train', transform=None):
        """
        Args:
            root_dir: Imagenette 数据集根目录 (imagenette2-320 或 imagenette2)
            split: 'train' 或 'val'
            transform: 图像变换
        """
        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.images = []
        self.labels = []
        
        self.class_to_idx = {cls_id: idx for idx, cls_id in enumerate(self.CLASSES)}
        self._load_data()
    
    def _load_data(self):
        """加载数据"""
        split_dir = os.path.join(self.root_dir, self.split)
        
        for class_id in self.CLASSES:
            class_dir = os.path.join(split_dir, class_id)
            if os.path.exists(class_dir):
                for img_name in os.listdir(class_dir):
                    if img_name.lower().endswith(('.jpeg', '.jpg', '.png')):
                        self.images.append(os.path.join(class_dir, img_name))
                        self.labels.append(self.class_to_idx[class_id])
    
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        label = self.labels[idx]
        
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        return image, label


def get_data_transforms(model_name, image_size=64):
    """
    获取不同模型的数据变换
    
    Args:
        model_name: 模型名称
        image_size: 目标图像大小
    """
    # 根据模型调整图像大小
    if model_name in ['inception_v3', 'googlenet']:
        # Inception V3 需要 299x299 的输入
        resize = 299
    elif model_name in ['alexnet', 'vgg']:
        # AlexNet 和 VGG 通常使用 224x224
        resize = 224
    elif model_name == 'resnet':
        resize = 224
    else:
        # LeNet 使用较小的图像
        resize = 64
    
    # 标准化参数（ImageNet 统计值）
    normalize = transforms.Normalize(
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225]
    )
    
    # 训练集变换（含数据增强）
    train_transform = transforms.Compose([
        transforms.Resize((resize, resize)),
        transforms.RandomHorizontalFlip(),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        normalize,
    ])
    
    # 验证集变换（不含数据增强）
    val_transform = transforms.Compose([
        transforms.Resize((resize, resize)),
        transforms.ToTensor(),
        normalize,
    ])
    
    return train_transform, val_transform


def get_data_loaders(data_dir, model_name, batch_size=64, num_workers=4,
                     num_classes=None, samples_per_class=None, dataset_type='tiny-imagenet'):
    """
    获取数据加载器
    
    Args:
        data_dir: 数据集目录
        model_name: 模型名称
        batch_size: 批次大小
        num_workers: 数据加载线程数
        num_classes: 使用的类别数量 (仅对 tiny-imagenet 有效)
        samples_per_class: 每类样本数 (仅对 tiny-imagenet 有效)
        dataset_type: 'tiny-imagenet' 或 'imagenette'
    
    Returns:
        train_loader, val_loader: 训练和验证数据加载器
    """
    train_transform, val_transform = get_data_transforms(model_name)
    
    if dataset_type == 'imagenette':
        train_dataset = ImagenetteDataset(
            root_dir=data_dir,
            split='train',
            transform=train_transform
        )
        val_dataset = ImagenetteDataset(
            root_dir=data_dir,
            split='val',
            transform=val_transform
        )
        class_count = 10
    else:
        train_dataset = TinyImageNetDataset(
            root_dir=data_dir,
            split='train',
            transform=train_transform,
            num_classes=num_classes,
            samples_per_class=samples_per_class
        )
        val_dataset = TinyImageNetDataset(
            root_dir=data_dir,
            split='val',
            transform=val_transform,
            num_classes=num_classes,
            samples_per_class=None
        )
        class_count = len(train_dataset.class_ids)
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    print(f"训练集大小: {len(train_dataset)}")
    print(f"验证集大小: {len(val_dataset)}")
    print(f"类别数量: {class_count}")
    
    return train_loader, val_loader


if __name__ == '__main__':
    # 测试数据加载
    data_dir = r'd:\Personal\Desktop\AI\实验\No.4\tiny-imagenet-200'
    train_loader, val_loader = get_data_loaders(data_dir, 'resnet', batch_size=32)
    
    # 查看一个批次
    images, labels = next(iter(train_loader))
    print(f"图像批次形状: {images.shape}")
    print(f"标签批次形状: {labels.shape}")
