# 实验四：经典卷积神经网络实现ImageNet图像分类

## 实验目的
1. 掌握几种经典CNN网络的结构及实现
2. 能够利用CNN网络解决图像分类问题

## 数据集
- **Tiny ImageNet**: ImageNet的子集
  - 200个类别
  - 训练集: 100,000张图片 (每类500张)
  - 验证集: 10,000张图片
  - 图像大小: 64×64

## 对比模型
| 模型 | 年份 | 特点 |
|------|------|------|
| LeNet | 1998 | 经典CNN结构，卷积+池化+全连接 |
| AlexNet | 2012 | ImageNet冠军，引入ReLU和Dropout |
| VGG | 2014 | 使用小卷积核(3×3)堆叠的深度网络 |
| GoogLeNet | 2014 | Inception模块，多尺度特征提取 |
| ResNet | 2015 | 残差连接，解决深度网络退化问题 |

## 文件结构
```
No.4/
├── tiny-imagenet-200/     # 数据集目录
├── data_loader.py         # 数据加载模块
├── models.py              # 模型定义模块
├── train.py               # 训练和评估模块
├── main.py                # 主实验脚本
├── quick_test.py          # 快速测试脚本
├── requirements.txt       # 依赖文件
├── checkpoints/           # 模型保存目录 (运行后生成)
└── results/               # 结果保存目录 (运行后生成)
```

## 使用方法

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 快速测试 (可选)
验证代码是否正常运行:
```bash
python quick_test.py
```

### 3. 运行完整实验
```bash
python main.py
```

## 配置参数
在 `main.py` 中可以修改以下参数:

```python
CONFIG = {
    'batch_size': 64,        # 批次大小
    'num_epochs': 30,        # 训练轮数
    'learning_rate': 0.001,  # 学习率
    'weight_decay': 1e-4,    # 权重衰减
    'pretrained': False,     # 是否使用预训练权重
}
```

## 输出结果
运行完成后，在 `results/` 目录下会生成:
- `training_curves.png` - 训练曲线对比图
- `accuracy_comparison.png` - 准确率对比柱状图
- `params_vs_accuracy.png` - 参数量与准确率关系图
- `experiment_report.txt` - 实验报告
- `{model_name}_results.json` - 各模型详细结果

## 评估指标
- **Top-1 Accuracy**: 预测概率最高的类别与真实标签一致的比例
- **Top-5 Accuracy**: 预测概率前5的类别中包含真实标签的比例

## 注意事项
1. 建议使用GPU进行训练，CPU训练会非常慢
2. VGG模型参数量较大，可能需要减小batch_size
3. Windows系统下，`num_workers` 建议设为0或较小值
4. 完整训练5个模型预计需要数小时(取决于硬件)

## 参考资料
- [ImageNet官网](http://www.image-net.org/)
- [Tiny ImageNet](http://cs231n.stanford.edu/tiny-imagenet-200.zip)
- [经典CNN网络详解](https://zhuanlan.zhihu.com/p/66215918)
