"""一次性训练所有 5 个模型"""
import os
import json
import torch
from datetime import datetime

from data_loader import get_data_loaders
from models import get_model, count_parameters
from train import Trainer, evaluate_model

# 配置 (Imagenette 10类)
CONFIG = {
    'data_dir': r'd:\Personal\Desktop\AI\实验\No.4\imagenette2-320',
    'save_dir': r'd:\Personal\Desktop\AI\实验\No.4\checkpoints',
    'results_dir': r'd:\Personal\Desktop\AI\实验\No.4\results',
    'num_epochs': 10,
    'learning_rate': 0.001,
    'weight_decay': 1e-4,
    'num_workers': 0,
    'num_classes': 10,
    'dataset_type': 'imagenette',
}

# 5 个模型配置: (模型名, batch_size)
MODELS = [
    ('lenet', 64),
    ('alexnet', 64),
    ('vgg', 32),
    ('resnet', 64),
    ('googlenet', 32),
]


def train_model(model_name, batch_size):
    """训练单个模型"""
    print(f"\n{'#'*60}")
    print(f"# 训练模型: {model_name.upper()}")
    print(f"# 开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'#'*60}")
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")
    
    # 加载数据
    train_loader, val_loader = get_data_loaders(
        data_dir=CONFIG['data_dir'],
        model_name=model_name,
        batch_size=batch_size,
        num_workers=CONFIG['num_workers'],
        dataset_type=CONFIG['dataset_type']
    )
    
    # 创建模型
    model = get_model(model_name, num_classes=CONFIG['num_classes'])
    print(f"参数量: {count_parameters(model):,}")
    
    # 训练
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        device=device,
        learning_rate=CONFIG['learning_rate'],
        weight_decay=CONFIG['weight_decay'],
        scheduler_type='cosine',
        model_name=model_name
    )
    
    history = trainer.train(num_epochs=CONFIG['num_epochs'], save_dir=CONFIG['save_dir'])
    
    # 评估
    trainer.load_best_model(CONFIG['save_dir'])
    results = evaluate_model(trainer.model, val_loader, device)
    
    # 保存结果
    save_data = {
        'model_name': model_name,
        'dataset': 'imagenette',
        'num_params': count_parameters(model),
        'top1_accuracy': results['top1_accuracy'],
        'top5_accuracy': results['top5_accuracy'],
        'loss': results['loss'],
        'history': history
    }
    
    result_path = os.path.join(CONFIG['results_dir'], f'{model_name}_results.json')
    with open(result_path, 'w') as f:
        json.dump(save_data, f, indent=2)
    
    print(f"结果已保存: {result_path}")
    print(f"Top-1: {results['top1_accuracy']:.2f}%, Top-5: {results['top5_accuracy']:.2f}%")
    
    return results


def main():
    print(f"{'='*60}")
    print(f"批量训练 5 个模型 (Imagenette 10类)")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}")
    
    os.makedirs(CONFIG['save_dir'], exist_ok=True)
    os.makedirs(CONFIG['results_dir'], exist_ok=True)
    
    all_results = {}
    
    for model_name, batch_size in MODELS:
        try:
            results = train_model(model_name, batch_size)
            all_results[model_name] = {
                'top1': results['top1_accuracy'],
                'top5': results['top5_accuracy']
            }
        except Exception as e:
            print(f"训练 {model_name} 失败: {e}")
            all_results[model_name] = {'error': str(e)}
    
    # 打印汇总
    print(f"\n{'='*60}")
    print("训练完成! 汇总结果:")
    print(f"{'='*60}")
    print(f"{'模型':<12} {'Top-1':>10} {'Top-5':>10}")
    print("-" * 34)
    for model_name, result in all_results.items():
        if 'error' in result:
            print(f"{model_name:<12} {'失败':>10}")
        else:
            print(f"{model_name:<12} {result['top1']:>9.2f}% {result['top5']:>9.2f}%")
    
    print(f"\n完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == '__main__':
    main()
