"""
训练和评估模块
"""
import os
import time
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR, CosineAnnealingLR
import numpy as np
from tqdm import tqdm


class Trainer:
    """模型训练器"""
    
    def __init__(self, model, train_loader, val_loader, device, 
                 learning_rate=0.001, weight_decay=1e-4, 
                 scheduler_type='step', model_name='model'):
        """
        Args:
            model: PyTorch 模型
            train_loader: 训练数据加载器
            val_loader: 验证数据加载器
            device: 计算设备
            learning_rate: 学习率
            weight_decay: 权重衰减
            scheduler_type: 学习率调度器类型 ('step' 或 'cosine')
            model_name: 模型名称（用于保存）
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.model_name = model_name
        
        # 损失函数
        self.criterion = nn.CrossEntropyLoss()
        
        # 优化器
        self.optimizer = optim.Adam(
            model.parameters(),
            lr=learning_rate,
            weight_decay=weight_decay
        )
        
        # 学习率调度器
        if scheduler_type == 'step':
            self.scheduler = StepLR(self.optimizer, step_size=10, gamma=0.1)
        else:
            self.scheduler = CosineAnnealingLR(self.optimizer, T_max=30)
        
        # 训练历史
        self.history = {
            'train_loss': [],
            'train_acc': [],
            'train_top5_acc': [],
            'val_loss': [],
            'val_acc': [],
            'val_top5_acc': [],
            'lr': []
        }
        
        self.best_val_acc = 0.0
        
    def train_epoch(self):
        """训练一个 epoch"""
        self.model.train()
        running_loss = 0.0
        correct_top1 = 0
        correct_top5 = 0
        total = 0
        
        pbar = tqdm(self.train_loader, desc='Training', leave=False)
        for images, labels in pbar:
            images, labels = images.to(self.device), labels.to(self.device)
            
            # 前向传播
            self.optimizer.zero_grad()
            outputs = self.model(images)
            
            # 处理 Inception V3 的辅助输出
            if isinstance(outputs, tuple):
                outputs, aux_outputs = outputs
                loss1 = self.criterion(outputs, labels)
                loss2 = self.criterion(aux_outputs, labels)
                loss = loss1 + 0.4 * loss2
            else:
                loss = self.criterion(outputs, labels)
            
            # 反向传播
            loss.backward()
            self.optimizer.step()
            
            # 统计
            running_loss += loss.item() * images.size(0)
            total += labels.size(0)
            
            # Top-1 准确率
            _, predicted = outputs.max(1)
            correct_top1 += predicted.eq(labels).sum().item()
            
            # Top-5 准确率
            _, top5_pred = outputs.topk(5, 1, True, True)
            top5_pred = top5_pred.t()
            correct = top5_pred.eq(labels.view(1, -1).expand_as(top5_pred))
            correct_top5 += correct.any(dim=0).sum().item()
            
            # 更新进度条
            pbar.set_postfix({
                'loss': f'{loss.item():.4f}',
                'top1': f'{100.*correct_top1/total:.2f}%',
                'top5': f'{100.*correct_top5/total:.2f}%'
            })
        
        epoch_loss = running_loss / total
        epoch_acc_top1 = 100. * correct_top1 / total
        epoch_acc_top5 = 100. * correct_top5 / total
        
        return epoch_loss, epoch_acc_top1, epoch_acc_top5
    
    def validate(self):
        """验证模型"""
        self.model.eval()
        running_loss = 0.0
        correct_top1 = 0
        correct_top5 = 0
        total = 0
        
        with torch.no_grad():
            pbar = tqdm(self.val_loader, desc='Validating', leave=False)
            for images, labels in pbar:
                images, labels = images.to(self.device), labels.to(self.device)
                
                outputs = self.model(images)
                
                # 处理 Inception V3
                if isinstance(outputs, tuple):
                    outputs = outputs[0]
                
                loss = self.criterion(outputs, labels)
                
                running_loss += loss.item() * images.size(0)
                total += labels.size(0)
                
                # Top-1 准确率
                _, predicted = outputs.max(1)
                correct_top1 += predicted.eq(labels).sum().item()
                
                # Top-5 准确率
                _, top5_pred = outputs.topk(5, 1, True, True)
                top5_pred = top5_pred.t()
                correct = top5_pred.eq(labels.view(1, -1).expand_as(top5_pred))
                correct_top5 += correct.any(dim=0).sum().item()
        
        epoch_loss = running_loss / total
        epoch_acc_top1 = 100. * correct_top1 / total
        epoch_acc_top5 = 100. * correct_top5 / total
        
        return epoch_loss, epoch_acc_top1, epoch_acc_top5
    
    def train(self, num_epochs, save_dir='checkpoints'):
        """
        训练模型
        
        Args:
            num_epochs: 训练轮数
            save_dir: 模型保存目录
        """
        os.makedirs(save_dir, exist_ok=True)
        
        print(f"\n{'='*60}")
        print(f"开始训练 {self.model_name}")
        print(f"{'='*60}")
        
        start_time = time.time()
        
        for epoch in range(num_epochs):
            epoch_start = time.time()
            
            # 训练
            train_loss, train_acc, train_top5_acc = self.train_epoch()
            
            # 验证
            val_loss, val_acc, val_top5_acc = self.validate()
            
            # 更新学习率
            current_lr = self.optimizer.param_groups[0]['lr']
            self.scheduler.step()
            
            # 记录历史
            self.history['train_loss'].append(train_loss)
            self.history['train_acc'].append(train_acc)
            self.history['train_top5_acc'].append(train_top5_acc)
            self.history['val_loss'].append(val_loss)
            self.history['val_acc'].append(val_acc)
            self.history['val_top5_acc'].append(val_top5_acc)
            self.history['lr'].append(current_lr)
            
            epoch_time = time.time() - epoch_start
            
            # 打印进度
            print(f"Epoch [{epoch+1}/{num_epochs}] - {epoch_time:.1f}s")
            print(f"  Train Loss: {train_loss:.4f}, Train Top-1: {train_acc:.2f}%, Train Top-5: {train_top5_acc:.2f}%")
            print(f"  Val Loss: {val_loss:.4f}, Val Top-1: {val_acc:.2f}%, Val Top-5: {val_top5_acc:.2f}%")
            print(f"  Learning Rate: {current_lr:.6f}")
            
            # 保存最佳模型
            if val_acc > self.best_val_acc:
                self.best_val_acc = val_acc
                save_path = os.path.join(save_dir, f'{self.model_name}_best.pth')
                torch.save({
                    'epoch': epoch,
                    'model_state_dict': self.model.state_dict(),
                    'optimizer_state_dict': self.optimizer.state_dict(),
                    'val_acc': val_acc,
                    'val_top5_acc': val_top5_acc
                }, save_path)
                print(f"  >> 保存最佳模型 (Top-1: {val_acc:.2f}%)")
        
        total_time = time.time() - start_time
        print(f"\n训练完成! 总用时: {total_time/60:.1f} 分钟")
        print(f"最佳验证准确率: Top-1 = {self.best_val_acc:.2f}%")
        
        return self.history
    
    def load_best_model(self, save_dir='checkpoints'):
        """加载最佳模型"""
        load_path = os.path.join(save_dir, f'{self.model_name}_best.pth')
        if os.path.exists(load_path):
            checkpoint = torch.load(load_path)
            self.model.load_state_dict(checkpoint['model_state_dict'])
            print(f"已加载最佳模型: {load_path}")
            return checkpoint
        else:
            print(f"未找到保存的模型: {load_path}")
            return None


def evaluate_model(model, data_loader, device):
    """
    评估模型性能
    
    Returns:
        results: 包含各项指标的字典
    """
    model.eval()
    criterion = nn.CrossEntropyLoss()
    
    total_loss = 0.0
    correct_top1 = 0
    correct_top5 = 0
    total = 0
    
    all_predictions = []
    all_labels = []
    
    with torch.no_grad():
        for images, labels in tqdm(data_loader, desc='Evaluating'):
            images, labels = images.to(device), labels.to(device)
            
            outputs = model(images)
            if isinstance(outputs, tuple):
                outputs = outputs[0]
            
            loss = criterion(outputs, labels)
            total_loss += loss.item() * images.size(0)
            total += labels.size(0)
            
            # Top-1
            _, predicted = outputs.max(1)
            correct_top1 += predicted.eq(labels).sum().item()
            
            # Top-5
            _, top5_pred = outputs.topk(5, 1, True, True)
            top5_pred = top5_pred.t()
            correct = top5_pred.eq(labels.view(1, -1).expand_as(top5_pred))
            correct_top5 += correct.any(dim=0).sum().item()
            
            all_predictions.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    results = {
        'loss': total_loss / total,
        'top1_accuracy': 100. * correct_top1 / total,
        'top5_accuracy': 100. * correct_top5 / total,
        'predictions': np.array(all_predictions),
        'labels': np.array(all_labels)
    }
    
    return results


if __name__ == '__main__':
    # 测试
    print("训练模块测试完成")
