"""
汇总所有模型结果并生成对比图表
在所有模型训练完成后运行此脚本
"""
import os
import json
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime


RESULTS_DIR = r'd:\Personal\Desktop\AI\实验\No.4\results'
MODELS = ['lenet', 'alexnet', 'vgg', 'googlenet', 'resnet']


def load_results():
    """加载所有模型的结果"""
    all_results = []
    missing = []
    
    for model_name in MODELS:
        result_path = os.path.join(RESULTS_DIR, f'{model_name}_results.json')
        if os.path.exists(result_path):
            with open(result_path, 'r') as f:
                data = json.load(f)
                all_results.append(data)
                print(f"✓ 已加载 {model_name.upper()} 结果")
        else:
            missing.append(model_name)
            print(f"✗ 未找到 {model_name.upper()} 结果: {result_path}")
    
    if missing:
        print(f"\n缺少以下模型的结果: {', '.join(missing)}")
        print("请先运行对应的训练脚本")
    
    return all_results


def plot_training_curves(all_results, save_dir):
    """绘制训练曲线对比图"""
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    
    for idx, result in enumerate(all_results):
        model_name = result['model_name'].upper()
        history = result['history']
        color = colors[idx % len(colors)]
        epochs = range(1, len(history['train_loss']) + 1)
        
        axes[0, 0].plot(epochs, history['train_loss'], label=model_name, color=color, linewidth=2)
        axes[0, 1].plot(epochs, history['val_loss'], label=model_name, color=color, linewidth=2)
        axes[1, 0].plot(epochs, history['train_acc'], label=model_name, color=color, linewidth=2)
        axes[1, 1].plot(epochs, history['val_acc'], label=model_name, color=color, linewidth=2)
    
    axes[0, 0].set_title('Training Loss', fontsize=12)
    axes[0, 0].set_xlabel('Epoch')
    axes[0, 0].set_ylabel('Loss')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    axes[0, 1].set_title('Validation Loss', fontsize=12)
    axes[0, 1].set_xlabel('Epoch')
    axes[0, 1].set_ylabel('Loss')
    axes[0, 1].legend()
    axes[0, 1].grid(True, alpha=0.3)
    
    axes[1, 0].set_title('Training Accuracy', fontsize=12)
    axes[1, 0].set_xlabel('Epoch')
    axes[1, 0].set_ylabel('Accuracy (%)')
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)
    
    axes[1, 1].set_title('Validation Accuracy (Top-1)', fontsize=12)
    axes[1, 1].set_xlabel('Epoch')
    axes[1, 1].set_ylabel('Accuracy (%)')
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'training_curves.png'), dpi=150)
    plt.close()
    print(f"训练曲线已保存: {os.path.join(save_dir, 'training_curves.png')}")


def plot_accuracy_comparison(all_results, save_dir):
    """绘制准确率对比柱状图"""
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    model_names = [r['model_name'].upper() for r in all_results]
    top1_accs = [r['top1_accuracy'] for r in all_results]
    top5_accs = [r['top5_accuracy'] for r in all_results]
    
    x = np.arange(len(model_names))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(12, 6))
    bars1 = ax.bar(x - width/2, top1_accs, width, label='Top-1 Accuracy', color='#3498db')
    bars2 = ax.bar(x + width/2, top5_accs, width, label='Top-5 Accuracy', color='#2ecc71')
    
    ax.set_xlabel('Model', fontsize=12)
    ax.set_ylabel('Accuracy (%)', fontsize=12)
    ax.set_title('Model Performance Comparison on Tiny ImageNet', fontsize=14)
    ax.set_xticks(x)
    ax.set_xticklabels(model_names)
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    for bar in bars1:
        height = bar.get_height()
        ax.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=9)
    for bar in bars2:
        height = bar.get_height()
        ax.annotate(f'{height:.1f}%', xy=(bar.get_x() + bar.get_width()/2, height),
                   xytext=(0, 3), textcoords="offset points", ha='center', va='bottom', fontsize=9)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'accuracy_comparison.png'), dpi=150)
    plt.close()
    print(f"准确率对比图已保存: {os.path.join(save_dir, 'accuracy_comparison.png')}")


def plot_params_vs_accuracy(all_results, save_dir):
    """绘制参数量与准确率关系图"""
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    
    fig, ax = plt.subplots(figsize=(10, 6))
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    
    for idx, result in enumerate(all_results):
        params = result['num_params'] / 1e6
        acc = result['top1_accuracy']
        ax.scatter(params, acc, s=200, c=colors[idx], label=result['model_name'].upper(),
                   edgecolors='black', linewidths=1.5, zorder=5)
    
    ax.set_xlabel('Parameters (Millions)', fontsize=12)
    ax.set_ylabel('Top-1 Accuracy (%)', fontsize=12)
    ax.set_title('Model Parameters vs Accuracy', fontsize=14)
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'params_vs_accuracy.png'), dpi=150)
    plt.close()
    print(f"参数量-准确率关系图已保存: {os.path.join(save_dir, 'params_vs_accuracy.png')}")


def generate_report(all_results, save_dir):
    """生成实验报告"""
    report_path = os.path.join(save_dir, 'experiment_report.txt')
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("=" * 70 + "\n")
        f.write("实验四：经典卷积神经网络实现ImageNet图像分类\n")
        f.write("=" * 70 + "\n\n")
        f.write("实验时间: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + "\n\n")
        
        f.write("一、模型对比结果\n")
        f.write("-" * 60 + "\n")
        f.write(f"{'模型':<12} {'参数量':<15} {'Top-1 (%)':<12} {'Top-5 (%)':<12} {'Loss':<10}\n")
        f.write("-" * 60 + "\n")
        
        for result in all_results:
            f.write(f"{result['model_name'].upper():<12} "
                   f"{result['num_params']:>12,}   "
                   f"{result['top1_accuracy']:>10.2f}   "
                   f"{result['top5_accuracy']:>10.2f}   "
                   f"{result['loss']:>8.4f}\n")
        
        f.write("\n二、结果分析\n")
        f.write("-" * 40 + "\n")
        
        best_top1 = max(all_results, key=lambda x: x['top1_accuracy'])
        best_top5 = max(all_results, key=lambda x: x['top5_accuracy'])
        smallest = min(all_results, key=lambda x: x['num_params'])
        
        f.write(f"1. Top-1 准确率最高: {best_top1['model_name'].upper()} ({best_top1['top1_accuracy']:.2f}%)\n")
        f.write(f"2. Top-5 准确率最高: {best_top5['model_name'].upper()} ({best_top5['top5_accuracy']:.2f}%)\n")
        f.write(f"3. 参数量最少: {smallest['model_name'].upper()} ({smallest['num_params']:,})\n\n")
        
        f.write("三、模型特点\n")
        f.write("-" * 40 + "\n")
        f.write("""
1. LeNet: 最经典的CNN，网络浅，参数少，特征提取能力有限
2. AlexNet: 2012年ImageNet冠军，引入ReLU和Dropout
3. VGG: 使用3x3小卷积核堆叠，网络更深，参数量大
4. GoogLeNet: Inception模块，多尺度特征提取，参数效率高
5. ResNet: 残差连接，解决深度网络退化问题
""")
    
    print(f"实验报告已保存: {report_path}")


def main():
    print("=" * 60)
    print("汇总实验结果")
    print("=" * 60)
    
    os.makedirs(RESULTS_DIR, exist_ok=True)
    
    # 加载结果
    all_results = load_results()
    
    if len(all_results) == 0:
        print("\n没有找到任何结果，请先训练模型")
        return
    
    print(f"\n共加载 {len(all_results)} 个模型的结果")
    
    # 生成图表
    print("\n生成对比图表...")
    plot_training_curves(all_results, RESULTS_DIR)
    plot_accuracy_comparison(all_results, RESULTS_DIR)
    plot_params_vs_accuracy(all_results, RESULTS_DIR)
    generate_report(all_results, RESULTS_DIR)
    
    # 打印结果摘要
    print("\n" + "=" * 60)
    print("实验结果摘要")
    print("=" * 60)
    print(f"{'模型':<12} {'参数量':<15} {'Top-1 (%)':<12} {'Top-5 (%)':<12}")
    print("-" * 55)
    for result in all_results:
        print(f"{result['model_name'].upper():<12} "
              f"{result['num_params']:>12,}   "
              f"{result['top1_accuracy']:>10.2f}   "
              f"{result['top5_accuracy']:>10.2f}")
    
    print(f"\n所有结果已保存到: {RESULTS_DIR}")


if __name__ == '__main__':
    main()
